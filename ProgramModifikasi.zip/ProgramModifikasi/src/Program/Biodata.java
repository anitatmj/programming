package Program;


import java.util.Date;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Biodata extends MIDlet implements CommandListener {

    private Display display;
    private Command Ok, Keluar, Kembali, Petunjuk;
    private StringItem nim, nama, kelas, jk, jurusan, alamat, prodi, sagama, TGL;
    private TextField namat, nimt, alamatt, kelast;
    private Ticker ticker;
    private DateField tgl;
    private Form form, hasil;
    Image image;
    private List petunjuk;
    private ChoiceGroup jkel, agama, pilihprodi, pilihjurusan;
    private int choiceGroup;
    private Alert alert;

    public void startApp() {
        display = Display.getDisplay(this);
        try {
            image = Image.createImage("/gambar/pnl.png");
        } catch (Exception e) {
        }

        form = new Form("Data Mahasiswa PNL");
        Keluar = new Command("Keluar", Command.EXIT, 0);
        Ok = new Command("Ok", Command.SCREEN, 0);
        Kembali = new Command("Kembali", Command.BACK, 0);
        Petunjuk = new Command("Tata Cara", Command.SCREEN, 0);

        namat = new TextField("Nama   : ", "", 20, TextField.ANY);
        nimt = new TextField("Nim :", "", 20, TextField.NUMERIC);
        kelast = new TextField("Kelas :", "", 6, TextField.NUMERIC);
        alamatt = new TextField("Alamat :", "", 20, TextField.ANY);


        tgl = new DateField("Tanggal Lahir", DateField.DATE);
        tgl.setDate(new Date());

        pilihjurusan = new ChoiceGroup("Jurusan", Choice.POPUP);
        pilihjurusan.append("--pilih jurusan--", null);
        pilihjurusan.append("Teknik Elektro", null);
        pilihjurusan.append("Teknik Sipil", null);
        pilihjurusan.append("Teknik Mesin", null);
        pilihjurusan.append("Teknik Kimia", null);
        pilihjurusan.append("TIK", null);



        pilihprodi = new ChoiceGroup("Program Studi", Choice.POPUP);
        pilihprodi.append("--pilih prodi--    ", null);
        pilihprodi.append("TMJ", null);
        pilihprodi.append("IT", null);

        jkel = new ChoiceGroup("Jenis kelamin", Choice.EXCLUSIVE);
        jkel.append("Laki-laki", null);
        jkel.append("Perempuan", null);

        agama = new ChoiceGroup("Agama     ", Choice.POPUP);
        agama.append("--pilih agama--  ", null);
        agama.append("Islam", null);
        agama.append("Kristen", null);
        agama.append("Hindu", null);
        agama.append("Buddha", null);

        ticker = new Ticker("Sistem Informasi Mahasiswa PNL");

        form.append(image);
        form.append(namat);
        form.append(nimt);
        form.append(jkel);
        form.append(tgl);
        form.append(kelast);
        form.append(pilihjurusan);
        form.append(pilihprodi);
        form.append(alamatt);
        form.append(agama);
        form.addCommand(Keluar);
        form.addCommand(Ok);
        form.addCommand(Petunjuk);
        form.setTicker(ticker);
        form.setCommandListener(this);


        petunjuk = new List("Petunjuk", Choice.IMPLICIT);
        petunjuk.append("1.Masukkan Nama Anda", null);
        petunjuk.append("2.Masukan NIM Anda", null);
        petunjuk.append("3.Masukkan Tanggal Lahir Anda", null);
        petunjuk.append("4.Pilih Jurusan Anda", null);
        petunjuk.append("5.Pilih Prodi Anda", null);
        petunjuk.append("5.Masukkan Alamat Anda", null);
        petunjuk.append("4.Pilih Agama Anda", null);
        petunjuk.addCommand(Kembali);
        petunjuk.addCommand(Keluar);
        petunjuk.setCommandListener(this);

        nama = new StringItem("Nama    : ", null);
        alamat = new StringItem("Alamat  : ", null);
        kelas = new StringItem("Kelas   : ", null);
        jk = new StringItem("Jenis Kelamin : ", null);
        nim = new StringItem("Nim     : ", null);
        TGL = new StringItem("Tanggal Lahir : ", null);
        jurusan = new StringItem("Jurusan : ", null);
        prodi = new StringItem("Prodi   : ", null);
        sagama = new StringItem("Agama   : ", null);

        hasil = new Form("Data Anda");
        hasil.append(nama);
        hasil.append(nim);
        hasil.append(TGL);
        hasil.append(jk);
        hasil.append(kelas);
        hasil.append(jurusan);
        hasil.append(prodi);
        hasil.append(alamat);
        hasil.append(sagama);
        hasil.addCommand(Keluar);
        hasil.addCommand(Kembali);
        hasil.setCommandListener(this);
        hasil.setTicker(ticker);
        display.setCurrent(form);
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
    }

    public void commandAction(Command c, Displayable d) {
        String NAMA, NIM, KELAS, TANGG, JUR, PRO, ALAMAT, AGAMA, JKEL;

        //jika tombol/command OK ditekan
        if (c == Ok) {
            if (namat.getString().equals("")) {
                String info = "Masih ada data yang belum diisi";
                alert = new Alert("informasi", info, null, AlertType.WARNING);
                alert.setTimeout(5000);
                display.setCurrent(alert, form);

            } else {
                NAMA = namat.getString();
                NIM = nimt.getString();
                KELAS = kelast.getString();
                JKEL = jkel.getString(jkel.getSelectedIndex());
                TANGG = tgl.getDate().toString();
                ALAMAT = alamatt.getString();
                PRO = pilihprodi.getString(pilihprodi.getSelectedIndex());
                JUR = pilihjurusan.getString(pilihjurusan.getSelectedIndex());
                AGAMA = agama.getString(agama.getSelectedIndex());


                nama.setText(NAMA);
                nim.setText(NIM);
                kelas.setText(KELAS);
                jurusan.setText(JUR);
                prodi.setText(PRO);
                alamat.setText(ALAMAT);
                sagama.setText(AGAMA);
                jk.setText(JKEL);
                TGL.setText(TANGG);
                display.setCurrent(hasil);

            }

        } else if (c == Petunjuk) {
            display.setCurrent(petunjuk);

        } else if (c == Keluar) { //jika tombol/command Exit ditekan
            destroyApp(true);
            notifyDestroyed();
        } else if (c == Kembali) { //jika tombol/command Back ditekan
            //menampilkan kembali form DataPribadi sebagai tampilan default/awal
            display.setCurrent(form);

        }
    }
}
